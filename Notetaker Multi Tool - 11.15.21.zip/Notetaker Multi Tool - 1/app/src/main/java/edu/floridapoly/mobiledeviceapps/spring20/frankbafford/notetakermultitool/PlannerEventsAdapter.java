package edu.floridapoly.mobiledeviceapps.spring20.frankbafford.notetakermultitool;

import android.content.Context;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import org.w3c.dom.Text;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class PlannerEventsAdapter extends RecyclerView.Adapter<PlannerEventsAdapter.MyViewHolder> {

    private Context context;
    private List<PlannerEvent> plannerEventsList;

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView note;
        public TextView dot;
        public TextView startDate;
        public TextView endDate;
        public TextView startTime;
        public TextView endTime;

        public MyViewHolder(View view) {
            super(view);
            note = view.findViewById(R.id.note);
            dot = view.findViewById(R.id.dot);
            startDate = view.findViewById(R.id.start_date);
            endDate = view.findViewById(R.id.end_date);
            startTime = view.findViewById(R.id.start_time);
            endTime = view.findViewById(R.id.end_time);
        }
    }


    public PlannerEventsAdapter(Context context, List<PlannerEvent> plannerEventsList) {
        this.context = context;
        this.plannerEventsList = plannerEventsList;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.planner_list_row, parent, false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        PlannerEvent note = plannerEventsList.get(position);

        holder.note.setText(note.getName());

        // Displaying dot from HTML character code
        holder.dot.setText(Html.fromHtml("&#8226;"));

        // Formatting and displaying date and time
        if(note.getStartDate() != null) {
            holder.startDate.setText(formatDate(note.getStartDate()));
        } else {
            holder.startDate.setText("");
        }
        if(note.getStartTime() != null) {
            holder.startTime.setText(formatTime(note.getStartTime()));
        } else {
            holder.startTime.setText("");
        }
        if(note.getEndDate() != null) {
            holder.endDate.setText("- " + formatDate(note.getEndDate()));
        } else {
            holder.endDate.setText("");
        }
        if(note.getEndTime() != null) {
            holder.endTime.setText(formatTime(note.getEndTime()));
        } else {
            holder.endTime.setText("");
        }
    }

    @Override
    public int getItemCount() {
        return plannerEventsList.size();
    }

    private String formatDate(Date date) {
        if (date != null) {
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(date);
            DateFormat df = android.text.format.DateFormat.getDateFormat(context);
            String formattedDate = df.format(calendar.getTime());
            return formattedDate;
        }
        return "";
    }

    private String formatTime(Date time) {
        if (time != null) {
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(time);
            String formattedDate = DateFormat.getTimeInstance(DateFormat.SHORT).format(calendar.getTime());
            return formattedDate;
        }
        return "";
    }
}
