package edu.floridapoly.mobiledeviceapps.spring20.frankbafford.notetakermultitool;


import java.util.Date;

public class Reminder extends Note{
    private Date startDate;
    private Date startTime;
    private boolean completed;

    //constructors
    public Reminder() {
    }
    public Reminder(int id, String name, String type, String text, Date startDate, Date startTime, boolean completed) {
        this.setId(id);
        this.setName(name);
        this.setType(type);
        this.setText(text);
        this.startDate = startDate;
        this.startTime = startTime;
        this.completed = completed;
    }

    //getter/setter methods
    public Date getStartDate() {
        return startDate;
    }
    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }
    public Date getStartTime() {
        return startTime;
    }
    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }
    public boolean isCompleted() {
        return completed;
    }
    public void setCompleted(boolean completed) {
        this.completed = completed;
    }
}
