package edu.floridapoly.mobiledeviceapps.spring20.frankbafford.notetakermultitool;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TimePicker;
import android.widget.Toast;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class CreatenoteScreen extends AppCompatActivity {

    List<Note> notesList = new ArrayList<>();
    List<Reminder> remindersList = new ArrayList<>();
    List<PlannerEvent> plannerEventList = new ArrayList<>();
    NotesAdapter mAdapter = new NotesAdapter(this, notesList);
    RemindersAdapter remindersAdapter = new RemindersAdapter(this, remindersList);
    PlannerEventsAdapter plannerEventsAdapter = new PlannerEventsAdapter(this, plannerEventList);
    DatabaseHelper db;

    Button saveButton;
    Button cancelButton;
    EditText textField;
    EditText titleField;

    ActivityResultLauncher<Intent> activityResultLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    // do something
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_createnote_screen);

        textField = findViewById(R.id.editTextTextMultiLine);
        titleField = findViewById(R.id.titleField);

        //Update notes list
        db = new DatabaseHelper(this);
        //notesList.addAll(db.getAllNotes());



        //Get boolean for if user wants to update already added note
        boolean shouldUpdate = getIntent().getBooleanExtra("SHOULD_UPDATE", false);
        //Get position of note if updating
        int position = getIntent().getIntExtra("POSITION", -1);

        //TYPE - note = 1, reminder = 2, planner = 3
        int noteType = getIntent().getIntExtra("TYPE", -1);

        //If updating note, fill in header and text box
        if(shouldUpdate) {
            if (noteType == 1) {
                notesList.addAll(db.getAllNotes());

                Note n = notesList.get(position);
                textField.setText(n.getText());
                titleField.setText(n.getName());
            }
            if (noteType == 2){
                remindersList.addAll(db.getAllReminders());

                Note n = remindersList.get(position);
                textField.setText(n.getText());
                titleField.setText(n.getName());
            }
            if (noteType == 3){
                plannerEventList.addAll(db.getAllPlannerEvents());

                Note n = plannerEventList.get(position);
                textField.setText(n.getText());
                titleField.setText(n.getName());
            }
        }

        saveButton = findViewById(R.id.saveBtn);
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Show toast message when no text is entered
                if (TextUtils.isEmpty(textField.getText().toString())) {
                    Toast.makeText(CreatenoteScreen.this, "Enter note!", Toast.LENGTH_SHORT).show();
                    return;
                } else if (TextUtils.isEmpty(titleField.getText().toString())) {
                    Toast.makeText(CreatenoteScreen.this, "Enter title!", Toast.LENGTH_SHORT).show();
                    return;
                }
                //Open dialog to choose where to save
                showActionsDialog(titleField, textField, shouldUpdate, position);
            }
        });

        cancelButton = findViewById(R.id.cancelBtn);
        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentData = new Intent(getBaseContext(), MainActivity.class);
                intentData.putExtra("NOTE_SAVED", false);
                setResult(RESULT_OK, intentData);
                activityResultLauncher.launch(intentData);
            }
        });

    }

    //Dialog to choose whether to save to notes, reminders, or planner
    private void showActionsDialog(EditText titleField, EditText textField, boolean shouldUpdate, int position) {
        CharSequence colors[] = new CharSequence[]{"Notes", "Reminders", "Planner"};

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Save To...");
        builder.setItems(colors, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                //selects notes
                if (which == 0) {
                    if(shouldUpdate) {
                        updateNote(titleField.getText().toString(), textField.getText().toString(), position);
                    } else {
                        createNote(titleField.getText().toString(), textField.getText().toString());
                    }
                    Intent intentData = new Intent(getBaseContext(), NotesScreen.class);
                    intentData.putExtra("NOTE_SAVED", true);
                    setResult(RESULT_OK, intentData);
                    activityResultLauncher.launch(intentData);
                }
                //selects reminders
                else if (which == 1) {
                    //open dialog to save reminder
                    showReminderDialog(shouldUpdate, position);
                //selects planner
                } else {
                    //open dialog to save planner
                    showCalendarDialog(shouldUpdate, position);
                }
            }
        });
        builder.show();
    }

    //dialog for saving a reminder
    public void showReminderDialog(boolean shouldUpdate, int position) {
        LayoutInflater layoutInflaterAndroid = LayoutInflater.from(getApplicationContext());
        View view = layoutInflaterAndroid.inflate(R.layout.reminder_dialog, null);

        AlertDialog.Builder alertDialogBuilderUserInput = new AlertDialog.Builder(CreatenoteScreen.this);
        alertDialogBuilderUserInput.setView(view);

        final Button dateButton = view.findViewById(R.id.date_button);
        final Button timeButton = view.findViewById(R.id.time_button);
        final Button saveButton = view.findViewById(R.id.save_button);

        final AlertDialog alertDialog = alertDialogBuilderUserInput.create();
        alertDialog.show();

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                DateFormat df = android.text.format.DateFormat.getDateFormat(getApplicationContext());
                DateFormat tf = DateFormat.getTimeInstance(DateFormat.SHORT);
                Date date = null;
                Date time = null;
                try {
                    if(!dateButton.getText().toString().equals("Date...")) {
                        date = df.parse(dateButton.getText().toString());
                    }
                    if(!timeButton.getText().toString().equals("Time...")) {
                        time = tf.parse(timeButton.getText().toString());
                    }
                } catch (Exception ex) {
                    Log.e("EXCEPTION", ex.toString());
                }

                if(shouldUpdate) {
                    updateReminder(titleField.getText().toString(), textField.getText().toString(), date, time, position);
                } else {
                    createReminder(titleField.getText().toString(), textField.getText().toString(), date, time);
                }

                alertDialog.dismiss();
                Intent intentData = new Intent(getBaseContext(), ReminderScreen.class);
                intentData.putExtra("NOTE_SAVED", true);
                setResult(RESULT_OK, intentData);
                activityResultLauncher.launch(intentData); //return to reminder screen
            }
        });

        dateButton.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void onClick(View v) {
                //open date picker
                showDatePickerDialog(view, R.id.date_button);
            }
        });
        timeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //open time picker
                showTimePickerDialog(view, R.id.time_button);
            }
        });
    }

    //dialog for saving a planner event
    public void showCalendarDialog(boolean shouldUpdate, int position) {
        LayoutInflater layoutInflaterAndroid = LayoutInflater.from(getApplicationContext());
        View view = layoutInflaterAndroid.inflate(R.layout.calendar_dialog, null);

        AlertDialog.Builder alertDialogBuilderUserInput = new AlertDialog.Builder(CreatenoteScreen.this);
        alertDialogBuilderUserInput.setView(view);

        final Button startDateButton = view.findViewById(R.id.start_date_button);
        final Button endDateButton = view.findViewById(R.id.end_date_button);
        final Button startTimeButton = view.findViewById(R.id.start_time_button);
        final Button endTimeButton = view.findViewById(R.id.end_time_button);
        final Button saveButton = view.findViewById(R.id.save_button);

        final AlertDialog alertDialog = alertDialogBuilderUserInput.create();
        alertDialog.show();

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                DateFormat df = android.text.format.DateFormat.getDateFormat(getApplicationContext());
                DateFormat tf = DateFormat.getTimeInstance(DateFormat.SHORT);
                Date startDate = null;
                Date endDate = null;
                Date startTime = null;
                Date endTime = null;
                try {
                    if(!startDateButton.getText().toString().equals("Date...")) {
                        startDate = df.parse(startDateButton.getText().toString());
                    }
                    if(!endDateButton.getText().toString().equals("Date...")) {
                        endDate = df.parse(endDateButton.getText().toString());
                    }
                    if(!startTimeButton.getText().toString().equals("Time...")) {
                        startTime = tf.parse(startTimeButton.getText().toString());
                    }
                    if(!endTimeButton.getText().toString().equals("Time...")) {
                        endTime = tf.parse(endTimeButton.getText().toString());
                    }
                } catch (Exception ex) {
                    Log.e("EXCEPTION", ex.toString());
                }

                if(shouldUpdate) {
                    updatePlannerEvent(titleField.getText().toString(), textField.getText().toString(), startDate, startTime, endDate, endTime, position);
                } else {
                    createPlannerEvent(titleField.getText().toString(), textField.getText().toString(), startDate, startTime, endDate, endTime);
                }

                alertDialog.dismiss();
                Intent intentData = new Intent(getBaseContext(), PlannerScreen.class);
                intentData.putExtra("NOTE_SAVED", true);
                setResult(RESULT_OK, intentData);
                activityResultLauncher.launch(intentData); //return to planner screen
            }
        });

        startDateButton.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void onClick(View v) {
                //open date picker
                showDatePickerDialog(view, R.id.start_date_button);
            }
        });
        endDateButton.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void onClick(View v) {
                //open date picker
                showDatePickerDialog(view, R.id.end_date_button);
            }
        });
        startTimeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //open time picker
                showTimePickerDialog(view, R.id.start_time_button);
            }
        });
        endTimeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //open time picker
                showTimePickerDialog(view, R.id.end_time_button);
            }
        });
    }

    //dialog for choosing a date
    @RequiresApi(api = Build.VERSION_CODES.O)
    public void showDatePickerDialog(View v, int button_id) {
        LayoutInflater layoutInflaterAndroid = LayoutInflater.from(getApplicationContext());
        View view = layoutInflaterAndroid.inflate(R.layout.date_picker_dialog, null);

        AlertDialog.Builder alertDialogBuilderUserInput = new AlertDialog.Builder(CreatenoteScreen.this);
        alertDialogBuilderUserInput.setView(view);

        final Button dateButton = v.findViewById(button_id);
        final Button doneButton = view.findViewById(R.id.done_button);
        final DatePicker datePicker = view.findViewById(R.id.date_picker);

        final AlertDialog alertDialog = alertDialogBuilderUserInput.create();
        alertDialog.show();

        datePicker.setOnDateChangedListener(new DatePicker.OnDateChangedListener() {
            @Override
            public void onDateChanged(DatePicker datePicker, int i, int i1, int i2) {
                int month = i1;
                int day = i2;
                int year = i;
                Calendar calendar = Calendar.getInstance();
                calendar.set(year, month, day);
                DateFormat df = android.text.format.DateFormat.getDateFormat(getApplicationContext());
                String formattedDate = df.format(calendar.getTime());

                dateButton.setText(formattedDate);


            }
        });

        doneButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                alertDialog.dismiss();
            }
        });
    }

    //dialog for choosing a time
    public void showTimePickerDialog(View v, int button_id) {
        LayoutInflater layoutInflaterAndroid = LayoutInflater.from(getApplicationContext());
        View view = layoutInflaterAndroid.inflate(R.layout.time_picker_dialog, null);

        AlertDialog.Builder alertDialogBuilderUserInput = new AlertDialog.Builder(CreatenoteScreen.this);
        alertDialogBuilderUserInput.setView(view);

        final Button timeButton = v.findViewById(button_id);
        final Button doneButton = view.findViewById(R.id.done_button);
        final TimePicker timePicker = view.findViewById(R.id.time_picker);

        final AlertDialog alertDialog = alertDialogBuilderUserInput.create();
        alertDialog.show();

        timePicker.setOnTimeChangedListener(new TimePicker.OnTimeChangedListener() {
            @Override
            public void onTimeChanged(TimePicker timePicker, int hourOfDay, int minute) {
                /*
                if (minute < 10) {
                    timeButton.setText(String.valueOf(hourOfDay) + ":0" + String.valueOf(minute)); //add a 0 if minute < 10 for formatting
                } else {
                    timeButton.setText(String.valueOf(hourOfDay) + ":" + String.valueOf(minute));
                }
                */
                Calendar calendar = Calendar.getInstance();
                calendar.set(Calendar.HOUR_OF_DAY, hourOfDay);
                calendar.set(Calendar.MINUTE, minute);
                String formattedDate = DateFormat.getTimeInstance(DateFormat.SHORT).format(calendar.getTime());
                timeButton.setText(formattedDate);
            }
        });

        doneButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                alertDialog.dismiss();
            }
        });
    }

    private void createNote(String name,String text) {
        // inserting note in db and getting
        // newly inserted note id
        long id = db.insertNote(name, text);

        // get the newly inserted note from db
        Note n = db.getNote(id);

        if (n != null) {
            // adding new note to array list at 0 position
            notesList.add(0, n);

            // refreshing the list
            mAdapter.notifyDataSetChanged();
        }
    }

    private void createReminder(String name, String text, Date date, Date time) {
        // inserting reminder in db and getting
        // newly inserted note id
        long id = db.insertReminder(name, text, date, time, false);

        // get the newly inserted note from db
        Reminder n = db.getReminder(id);

        if (n != null) {
            // adding new note to array list at 0 position
            remindersList.add(0, n);

            // refreshing the list
            remindersAdapter.notifyDataSetChanged();
        }
    }

    private void createPlannerEvent(String name, String text, Date startDate, Date startTime, Date endDate, Date endTime) {
        // inserting event in db and getting
        // newly inserted note id
        long id = db.insertPlannerEvent(name, text, startDate, startTime, endDate, endTime);

        // get the newly inserted note from db
        PlannerEvent n = db.getPlannerEvent(id);

        if (n != null) {
            // adding new note to array list at 0 position
            plannerEventList.add(0, n);

            // refreshing the list
            plannerEventsAdapter.notifyDataSetChanged();
        }
    }

    private void updateNote(String name, String text, int position) {
        Note n = notesList.get(position);
        // updating note text
        n.setName(name);
        n.setText(text);

        // updating note in db
        db.updateNote(n);

        // refreshing the list
        notesList.set(position, n);
        mAdapter.notifyItemChanged(position);
    }

    private void updateReminder(String name, String text, Date date, Date time, int position) {
        Reminder n = remindersList.get(position);
        // updating note details
        n.setName(name);
        n.setText(text);
        n.setStartDate(date);
        n.setStartTime(time);

        // updating note in db
        db.updateReminder(n);

        // refreshing the list
        remindersList.set(position, n);
        remindersAdapter.notifyItemChanged(position);
    }

    private void updatePlannerEvent(String name, String text, Date startDate, Date startTime, Date endDate, Date endTime, int position) {
        PlannerEvent n = plannerEventList.get(position);
        // updating note details
        n.setName(name);
        n.setText(text);
        n.setStartDate(startDate);
        n.setStartTime(startTime);
        n.setEndDate(endDate);
        n.setEndTime(endTime);

        // updating note in db
        db.updatePlannerEvent(n);

        // refreshing the list
        plannerEventList.set(position, n);
        plannerEventsAdapter.notifyItemChanged(position);
    }

    private void deleteNote(int position) {
        // deleting the note from db
        db.deleteNote(notesList.get(position));

        // removing the note from the list
        notesList.remove(position);
        mAdapter.notifyItemRemoved(position);
    }

    private void deleteReminder(int position) {
        // deleting the note from db
        db.deleteReminder(remindersList.get(position));

        // removing the note from the list
        remindersList.remove(position);
        remindersAdapter.notifyItemRemoved(position);
    }

    private void deletePlannerEvent(int position) {
        // deleting the note from db
        db.deletePlannerEvent(plannerEventList.get(position));

        // removing the note from the list
        plannerEventList.remove(position);
        plannerEventsAdapter.notifyItemRemoved(position);
    }
}