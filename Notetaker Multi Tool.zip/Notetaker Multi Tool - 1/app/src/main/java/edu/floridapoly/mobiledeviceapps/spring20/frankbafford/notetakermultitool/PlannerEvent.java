package edu.floridapoly.mobiledeviceapps.spring20.frankbafford.notetakermultitool;


import java.util.Date;

public class PlannerEvent extends Note{
    private Date startDate;
    private Date endDate;
    private Date startTime;
    private Date endTime;

    //constructors
    public PlannerEvent() {
    }
    public PlannerEvent(int id, String name, String type, String text, Date startDate, Date endDate, Date startTime, Date endTime) {
        this.setId(id);
        this.setName(name);
        this.setType(type);
        this.setText(text);
        this.startDate = startDate;
        this.endDate = endDate;
        this.startTime = startTime;
        this.endTime = endTime;
    }

    //getter/setter methods
    public Date getStartDate() {
        return startDate;
    }
    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }
    public Date getEndDate() {
        return endDate;
    }
    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }
    public Date getStartTime() {
        return startTime;
    }
    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }
    public Date getEndTime() {
        return endTime;
    }
    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }
}
