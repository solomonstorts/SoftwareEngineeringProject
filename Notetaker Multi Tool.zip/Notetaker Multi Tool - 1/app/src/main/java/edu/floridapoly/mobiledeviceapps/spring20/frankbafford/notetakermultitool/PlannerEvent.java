package edu.floridapoly.mobiledeviceapps.spring20.frankbafford.notetakermultitool;



public class PlannerEvent extends Note{
    private String startDate;
    private String endDate;
    private String startTime;
    private String endTime;

    //constructors
    public PlannerEvent() {
    }
    public PlannerEvent(int id, String name, String type, String text, String startDate, String endDate, String startTime, String endTime) {
        this.setId(id);
        this.setName(name);
        this.setType(type);
        this.setText(text);
        this.startDate = startDate;
        this.endDate = endDate;
        this.startTime = startTime;
        this.endTime = endTime;
    }

    //getter/setter methods
    public String getStartDate() {
        return startDate;
    }
    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }
    public String getEndDate() {
        return endDate;
    }
    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }
    public String getStartTime() {
        return startTime;
    }
    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }
    public String getEndTime() {
        return endTime;
    }
    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }
}
