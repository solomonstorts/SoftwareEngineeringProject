package edu.floridapoly.mobiledeviceapps.spring20.frankbafford.notetakermultitool;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {
    //database version
    private static final int DATABASE_VERSION = 1;
    //database name
    private static final String DATABASE_NAME = "notetaker_multi_tool_db";
    //table names
    public static final String NOTES_TABLE_NAME = "notes";
    public static final String PLANNER_TABLE_NAME = "planner";
    public static final String REMINDERS_TABLE_NAME = "reminders";
    //column names
    public static final String COLUMN_ID = "id";
    public static final String COLUMN_NAME = "name";
    public static final String COLUMN_TYPE = "type";
    public static final String COLUMN_TEXT = "text";
    public static final String COLUMN_START_DATE = "start_date";
    public static final String COLUMN_END_DATE = "end_date";
    public static final String COLUMN_START_TIME = "start_time";
    public static final String COLUMN_END_TIME = "end_time";
    public static final String COLUMN_COMPLETED = "completed";
    //query to create notes table
    public static final String CREATE_NOTES_TABLE =
            "CREATE TABLE " + NOTES_TABLE_NAME + "("
                    + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                    + COLUMN_NAME + " TEXT,"
                    + COLUMN_TYPE + " TEXT,"
                    + COLUMN_TEXT + " TEXT"
                    + ")";
    //query to create planner table
    public static final String CREATE_PLANNER_TABLE =
            "CREATE TABLE " + PLANNER_TABLE_NAME + "("
                    + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                    + COLUMN_NAME + " TEXT,"
                    + COLUMN_TYPE + " TEXT,"
                    + COLUMN_TEXT + " TEXT,"
                    + COLUMN_START_DATE + " LONG, "
                    + COLUMN_END_DATE + " LONG, "
                    + COLUMN_START_TIME + " LONG, "
                    + COLUMN_END_TIME + " LONG"
                    + ")";
    //query to create reminders table
    public static final String CREATE_REMINDERS_TABLE =
            "CREATE TABLE " + REMINDERS_TABLE_NAME + "("
                    + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                    + COLUMN_NAME + " TEXT,"
                    + COLUMN_TYPE + " TEXT,"
                    + COLUMN_TEXT + " TEXT,"
                    + COLUMN_START_DATE + " LONG, "
                    + COLUMN_START_TIME + " LONG, "
                    + COLUMN_COMPLETED + " TEXT"
                    + ")";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // Creating Tables
    @Override
    public void onCreate(SQLiteDatabase db) {
        // create notes table
        db.execSQL(CREATE_NOTES_TABLE);
        // create planner table
        db.execSQL(CREATE_PLANNER_TABLE);
        // create reminders table
        db.execSQL(CREATE_REMINDERS_TABLE);
    }

    // Upgrading database
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop older tables if existed
        db.execSQL("DROP TABLE IF EXISTS " + NOTES_TABLE_NAME);
        db.execSQL("DROP TABLE IF EXISTS " + PLANNER_TABLE_NAME);
        db.execSQL("DROP TABLE IF EXISTS " + REMINDERS_TABLE_NAME);

        // Create tables again
        onCreate(db);
    }
    //insert a note
    public long insertNote(String name,String text) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(COLUMN_NAME, name);
        values.put(COLUMN_TYPE, "note");
        values.put(COLUMN_TEXT, text);

        // insert row
        long id = db.insert(NOTES_TABLE_NAME, null, values);
        // close db connection
        db.close();
        // return newly inserted row id
        return id;
    }
    //insert a planner event
    public long insertPlannerEvent(String name, String text, Date startDate, Date endDate, Date startTime, Date endTime) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(COLUMN_NAME, name);
        values.put(COLUMN_TYPE, "planner");
        values.put(COLUMN_TEXT, text);
        values.put(COLUMN_START_DATE, startDate.getTime());
        values.put(COLUMN_END_DATE, endDate.getTime());
        values.put(COLUMN_START_TIME, startTime.getTime());
        values.put(COLUMN_END_TIME, endTime.getTime());

        // insert row
        long id = db.insert(PLANNER_TABLE_NAME, null, values);
        // close db connection
        db.close();
        // return newly inserted row id
        return id;
    }
    //insert a reminder
    public long insertReminder(String name, String text, Date startDate, Date startTime, boolean completed) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(COLUMN_NAME, name);
        values.put(COLUMN_TYPE, "reminder");
        values.put(COLUMN_TEXT, text);
        values.put(COLUMN_START_DATE, startDate.getTime());
        values.put(COLUMN_START_TIME, startTime.getTime());
        values.put(COLUMN_COMPLETED, completed);

        // insert row
        long id = db.insert(REMINDERS_TABLE_NAME, null, values);
        // close db connection
        db.close();
        // return newly inserted row id
        return id;
    }
    //retrieve a note
    public Note getNote(long id) {
        // get readable database as we are not inserting anything
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(NOTES_TABLE_NAME,
                new String[]{COLUMN_ID, COLUMN_NAME, COLUMN_TYPE, COLUMN_TEXT},
                COLUMN_ID + "=?",
                new String[]{String.valueOf(id)}, null, null, null, null);

        if (cursor != null)
            cursor.moveToFirst();

        // prepare note object
        Note note = new Note(
                cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ID)),
                cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_NAME)),
                cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_TYPE)),
                cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_TEXT)));

        // close the db connection
        cursor.close();

        return note;
    }
    //retrieve a planner event
    public PlannerEvent getPlannerEvent(long id) {
        // get readable database as we are not inserting anything
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(PLANNER_TABLE_NAME,
                new String[]{COLUMN_ID, COLUMN_NAME, COLUMN_TYPE, COLUMN_TEXT, COLUMN_START_DATE, COLUMN_END_DATE, COLUMN_START_TIME, COLUMN_END_TIME},
                COLUMN_ID + "=?",
                new String[]{String.valueOf(id)}, null, null, null, null);

        if (cursor != null)
            cursor.moveToFirst();

        // prepare planner event object
        PlannerEvent event = new PlannerEvent(
                cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ID)),
                cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_NAME)),
                cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_TYPE)),
                cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_TEXT)),
                new Date(cursor.getLong(cursor.getColumnIndexOrThrow(COLUMN_START_DATE))),
                new Date(cursor.getLong(cursor.getColumnIndexOrThrow(COLUMN_END_DATE))),
                new Date(cursor.getLong(cursor.getColumnIndexOrThrow(COLUMN_START_TIME))),
                new Date(cursor.getLong(cursor.getColumnIndexOrThrow(COLUMN_END_TIME))));

        // close the db connection
        cursor.close();

        return event;
    }
    //retrieve a reminder
    public Reminder getReminder(long id) {
        // get readable database as we are not inserting anything
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(REMINDERS_TABLE_NAME,
                new String[]{COLUMN_ID, COLUMN_NAME, COLUMN_TYPE, COLUMN_TEXT, COLUMN_START_DATE, COLUMN_START_TIME, COLUMN_COMPLETED},
                COLUMN_ID + "=?",
                new String[]{String.valueOf(id)}, null, null, null, null);

        if (cursor != null)
            cursor.moveToFirst();

        // prepare reminder object
        Reminder reminder = new Reminder(
                cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ID)),
                cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_NAME)),
                cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_TYPE)),
                cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_TEXT)),
                new Date(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_START_DATE))),
                new Date(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_START_TIME))),
                Boolean.parseBoolean(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_COMPLETED))));

        // close the db connection
        cursor.close();

        return reminder;
    }
    //get all notes
    public List<Note> getAllNotes() {
        List<Note> notes = new ArrayList<>();

        // Select All Query
        String selectQuery = "SELECT  * FROM " + NOTES_TABLE_NAME;

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                Note note = new Note();
                note.setId(cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ID)));
                note.setName(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_NAME)));
                note.setType(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_TYPE)));
                note.setText(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_TEXT)));
                notes.add(note);
            } while (cursor.moveToNext());
        }

        // close db connection
        db.close();

        // return notes list
        return notes;
    }
    //get all planner events
    public List<PlannerEvent> getAllPlannerEvents() {
        List<PlannerEvent> plannerEvents = new ArrayList<>();

        // Select All Query
        String selectQuery = "SELECT  * FROM " + PLANNER_TABLE_NAME;

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                PlannerEvent plannerEvent = new PlannerEvent();
                plannerEvent.setId(cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ID)));
                plannerEvent.setName(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_NAME)));
                plannerEvent.setType(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_TYPE)));
                plannerEvent.setText(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_TEXT)));
                plannerEvent.setStartDate(new Date(cursor.getLong(cursor.getColumnIndexOrThrow(COLUMN_START_DATE))));
                plannerEvent.setEndDate(new Date(cursor.getLong(cursor.getColumnIndexOrThrow(COLUMN_END_DATE))));
                plannerEvent.setStartTime(new Date(cursor.getLong(cursor.getColumnIndexOrThrow(COLUMN_START_TIME))));
                plannerEvent.setEndTime(new Date(cursor.getLong(cursor.getColumnIndexOrThrow(COLUMN_END_TIME))));
                plannerEvents.add(plannerEvent);
            } while (cursor.moveToNext());
        }

        // close db connection
        db.close();

        // return planner events list
        return plannerEvents;
    }
    //get all reminders
    public List<Reminder> getAllReminders() {
        List<Reminder> reminders = new ArrayList<>();

        // Select All Query
        String selectQuery = "SELECT  * FROM " + REMINDERS_TABLE_NAME;

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                Reminder reminder = new Reminder();
                reminder.setId(cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ID)));
                reminder.setName(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_NAME)));
                reminder.setType(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_TYPE)));
                reminder.setText(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_TEXT)));
                reminder.setStartDate(new Date(cursor.getLong(cursor.getColumnIndexOrThrow(COLUMN_START_DATE))));
                reminder.setStartTime(new Date(cursor.getLong(cursor.getColumnIndexOrThrow(COLUMN_START_TIME))));
                reminder.setCompleted(Boolean.parseBoolean(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_COMPLETED))));
                reminders.add(reminder);
            } while (cursor.moveToNext());
        }

        // close db connection
        db.close();

        // return reminders list
        return reminders;
    }

    public int getNotesCount() {
        String countQuery = "SELECT  * FROM " + NOTES_TABLE_NAME;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(countQuery, null);
        int count = cursor.getCount();
        cursor.close();
        // return count
        return count;
    }

    public int getPlannerEventsCount() {
        String countQuery = "SELECT  * FROM " + PLANNER_TABLE_NAME;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(countQuery, null);
        int count = cursor.getCount();
        cursor.close();
        // return count
        return count;
    }

    public int getRemindersCount() {
        String countQuery = "SELECT  * FROM " + REMINDERS_TABLE_NAME;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(countQuery, null);
        int count = cursor.getCount();
        cursor.close();
        // return count
        return count;
    }

    public int updateNote(Note note) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COLUMN_NAME, note.getName());
        values.put(COLUMN_TEXT, note.getText());

        // updating row
        return db.update(NOTES_TABLE_NAME, values, COLUMN_ID + " = ?",
                new String[]{String.valueOf(note.getId())});
    }

    public int updatePlannerEvent(PlannerEvent event) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COLUMN_NAME, event.getName());
        values.put(COLUMN_TEXT, event.getText());
        values.put(COLUMN_START_DATE, event.getStartDate().getTime());
        values.put(COLUMN_END_DATE, event.getEndDate().getTime());
        values.put(COLUMN_START_TIME, event.getStartTime().getTime());
        values.put(COLUMN_END_TIME, event.getEndTime().getTime());

        // updating row
        return db.update(PLANNER_TABLE_NAME, values, COLUMN_ID + " = ?",
                new String[]{String.valueOf(event.getId())});
    }

    public int updateReminder(Reminder reminder) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COLUMN_NAME, reminder.getName());
        values.put(COLUMN_TEXT, reminder.getText());
        values.put(COLUMN_START_DATE, reminder.getStartDate().getTime());
        values.put(COLUMN_START_TIME, reminder.getStartTime().getTime());
        values.put(COLUMN_COMPLETED, Boolean.toString(reminder.isCompleted()));

        // updating row
        return db.update(REMINDERS_TABLE_NAME, values, COLUMN_ID + " = ?",
                new String[]{String.valueOf(reminder.getId())});
    }

    public void deleteNote(Note note) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(NOTES_TABLE_NAME, COLUMN_ID + " = ?",
                new String[]{String.valueOf(note.getId())});
        db.close();
    }

    public void deletePlannerEvent(PlannerEvent event) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(PLANNER_TABLE_NAME, COLUMN_ID + " = ?",
                new String[]{String.valueOf(event.getId())});
        db.close();
    }

    public void deleteReminder(Reminder reminder) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(PLANNER_TABLE_NAME, COLUMN_ID + " = ?",
                new String[]{String.valueOf(reminder.getId())});
        db.close();
    }
}
