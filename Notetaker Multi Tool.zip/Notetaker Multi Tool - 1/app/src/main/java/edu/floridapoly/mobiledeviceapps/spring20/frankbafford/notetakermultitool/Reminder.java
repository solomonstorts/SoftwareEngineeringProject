package edu.floridapoly.mobiledeviceapps.spring20.frankbafford.notetakermultitool;


public class Reminder extends Note{
    private String startDate;
    private String startTime;
    private boolean completed;

    //constructors
    public Reminder() {
    }
    public Reminder(int id, String name, String type, String text, String startDate, String startTime, boolean completed) {
        this.setId(id);
        this.setName(name);
        this.setType(type);
        this.setText(text);
        this.startDate = startDate;
        this.startTime = startTime;
        this.completed = completed;
    }

    //getter/setter methods
    public String getStartDate() {
        return startDate;
    }
    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }
    public String getStartTime() {
        return startTime;
    }
    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }
    public boolean isCompleted() {
        return completed;
    }
    public void setCompleted(boolean completed) {
        this.completed = completed;
    }
}
