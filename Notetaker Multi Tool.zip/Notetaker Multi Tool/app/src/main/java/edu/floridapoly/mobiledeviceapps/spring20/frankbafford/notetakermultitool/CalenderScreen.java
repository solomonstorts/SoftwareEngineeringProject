package edu.floridapoly.mobiledeviceapps.spring20.frankbafford.notetakermultitool;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class CalenderScreen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calender_screen);
    }
}