README

Notetaker Multitool Application

Group Members: Solomon Storts, Juhyung Kim, Frank Bafford

Source Description:

	This is the source code for the Notetaker Multitool Application.
	The application provides a convenient combination of Notes, Reminders, and a Planner for students.
	The application is written for Android devices and can be run using Android Studio.

Build Instructions:

	1. To build the application, download the Android Studio IDE: https://developer.android.com/studio
	2. Go to file->open and select the NotetakerMultitoolFinal folder.
	3. Create an Android Virtual Device: https://developer.android.com/studio/run/managing-avds
	4. Build and run the application.

How the Code is Organized:
	
	This Android application is created using java for the backend and XML for the frontend.
	The java source code is located in app/src/main/java/edu/floridapoly/mobiledeviceapps/spring20/frankbafford/notetakermultitool
	The XML layout files are located in app/src/main/res/layout

3rd Part Library:

	All development work was done by the team, and the only libraries used are Android standard libraries.

Contributions:

    Solomon - Basic database functionality (40%)
    Frank - UI design, all other functionality (60%)