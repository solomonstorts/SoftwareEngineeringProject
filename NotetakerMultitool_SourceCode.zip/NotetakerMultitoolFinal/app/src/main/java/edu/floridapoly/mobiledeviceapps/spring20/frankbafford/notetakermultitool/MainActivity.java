/*
 * Notetaker Multitool Application
 * MainActivity.java
 *
 * Code for Menu Screen, launches various activities depending on button clicked
 */

package edu.floridapoly.mobiledeviceapps.spring20.frankbafford.notetakermultitool;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    Button notesButton;
    Button plannerButton;
    Button remindersButton;
    Button createNoteButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ActivityResultLauncher<Intent> activityResultLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                new ActivityResultCallback<ActivityResult>() {
                    @Override
                    public void onActivityResult(ActivityResult result) {
                        // do something
                    }
                });

        notesButton = findViewById(R.id.noteBtn);
        notesButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent =new Intent(getBaseContext(), NotesScreen.class);
                activityResultLauncher.launch(intent);
            }
        });

        plannerButton = findViewById(R.id.plannerBtn);
        plannerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent =new Intent(getBaseContext(), PlannerScreen.class);
                activityResultLauncher.launch(intent);
            }
        });

        remindersButton = findViewById(R.id.remindersBtn);
        remindersButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent =new Intent(getBaseContext(), ReminderScreen.class);
                activityResultLauncher.launch(intent);
            }
        });

        createNoteButton = findViewById(R.id.temp);
        createNoteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent =new Intent(getBaseContext(), CreatenoteScreen.class);
                activityResultLauncher.launch(intent);
            }
        });
    }
}