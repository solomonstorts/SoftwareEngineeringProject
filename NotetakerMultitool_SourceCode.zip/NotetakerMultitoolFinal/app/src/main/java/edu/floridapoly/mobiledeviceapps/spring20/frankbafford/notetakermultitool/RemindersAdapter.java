/*
 * Notetaker Multitool Application
 * RemindersAdapter.java
 *
 * Manages recyclerView for Reminders Screen
 */

package edu.floridapoly.mobiledeviceapps.spring20.frankbafford.notetakermultitool;

import android.content.Context;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.RadioButton;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class RemindersAdapter extends RecyclerView.Adapter<RemindersAdapter.MyViewHolder> {

    private Context context;
    private List<Reminder> remindersList;

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView note;
        public TextView dot;
        public TextView date;
        public TextView time;
        public RadioButton completedButton;

        public MyViewHolder(View view) {
            super(view);
            note = view.findViewById(R.id.note);
            dot = view.findViewById(R.id.dot);
            date = view.findViewById(R.id.date);
            time = view.findViewById(R.id.time);
            completedButton = view.findViewById(R.id.completed_button);
        }
    }


    public RemindersAdapter(Context context, List<Reminder> remindersList) {
        this.context = context;
        this.remindersList = remindersList;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.reminder_list_row, parent, false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        Reminder note = remindersList.get(position);

        holder.note.setText(note.getName());

        // Displaying dot from HTML character code
        holder.dot.setText(Html.fromHtml("&#8226;"));

        // Formatting and displaying date and time
        if(note.getStartDate() != null) {
            holder.date.setText(formatDate(note.getStartDate()));
        } else {
            holder.date.setText("");
        }
        if(note.getStartTime() != null) {
            holder.time.setText(formatTime(note.getStartTime()));
        } else {
            holder.date.setText("");
        }

        if(note.isCompleted()) {
            holder.completedButton.toggle();
        }
    }

    @Override
    public int getItemCount() {
        return remindersList.size();
    }

     private String formatDate(Date date) {
         if (date != null) {
             Calendar calendar = Calendar.getInstance();
             calendar.setTime(date);
             DateFormat df = android.text.format.DateFormat.getDateFormat(context);
             String formattedDate = df.format(calendar.getTime());
             return formattedDate;
         }
         return "";
     }

    private String formatTime(Date time) {
        if (time != null) {
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(time);
            String formattedDate = DateFormat.getTimeInstance(DateFormat.SHORT).format(calendar.getTime());
            return formattedDate;
        }
        return "";
    }
}